﻿using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace AppointmentMaker.Models
{
    public class AppointmentModel
    {
        public AppointmentModel()
        {

        }

        public AppointmentModel(string patientName, string street, string city, string state, int zipCode, string email, int phoneNumber, DateTime dateTime, decimal patientNetWorth, string doctorName, int painLevel)
        {
            this.patientName = patientName;
            this.street = street;
            this.city = city;
            this.state = state;
            this.zipCode = zipCode;
            this.email = email;
            this.phoneNumber = phoneNumber;
            this.dateTime = dateTime;
            this.patientNetWorth = patientNetWorth;
            DoctorName = doctorName;
            PainLevel = painLevel;
        }

        [Required]
        [DisplayName("Patient's Full Name")]
        [StringLength(20, MinimumLength = 4)]
        public string patientName { get; set; }
        [Required]
        [DisplayName("Street Address")]
        [StringLength(20, MinimumLength = 4)]
        public string street { get; set; }
        [Required]
        [DisplayName("City")]
        [StringLength(20, MinimumLength = 4)]
        public string city { get; set; }
        [Required]
        [DisplayName("Patient's State")]
        [StringLength(20, MinimumLength = 4)]
        public string state { get; set; }
        [Required]
        [DisplayName("Patient's Zip Code")]
        public int zipCode { get; set; }
        [Required]
        [DisplayName("Patient's Email")]
        [StringLength(20, MinimumLength = 4)]
        public string email { get; set; }
        [Required]
        [DisplayName("Patient's Phone Number")]
        public int phoneNumber { get; set; }
        [Required]
        [DataType(DataType.Date)]
        [DisplayName("Appointment Request Date")]
        public DateTime dateTime { get; set; }
        [DisplayName("Patient's Approximate Net Worth")]
        public decimal patientNetWorth { get; set; }
        [DisplayName("Primary Doctors Last Name")]
        public string DoctorName { get; set; }
        [Required]
        [Range(1, 10)]
        [DisplayName("Patient's perceived level of pain (1 low 10 high)")]
        public int PainLevel { get; set; }
    }

}
