!insert into dbo.Users (USERNAME, PASSWORD) VALUES ('Joninno', 'Password!')

select * from dbo.Users