﻿using Microsoft.AspNetCore.Mvc;

namespace ButtonGrid.Models
{
    public class ButtonModel
    {
        public int Id { get; set; }
        public int ButtonState { get; set; }
    }
}

