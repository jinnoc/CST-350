﻿using RegisterAndLoginApp.Models;
using System.Collections.Generic;
using System.Linq;

namespace RegisterAndLoginApp.Services
{
    public class SecurityService
    {

        List<UserModel> usersDAO = new List<UserModel>();

        public SecurityService()
        {
            usersDAO.Add(new UserModel { Id = 0, UserName = "Joninno", Password = "gcu1234" });
            usersDAO.Add(new UserModel { Id = 1, UserName = "Bass", Password = "gcu1234" });
            usersDAO.Add(new UserModel { Id = 2, UserName = "Kobe", Password = "gcu1234" });
        }

        public bool IsValid(UserModel user)
        {
            return usersDAO.Any(XmlConfigurationExtensions=> XmlConfigurationExtensions.UserName == user.UserName && XmlConfigurationExtensions.Password == user.Password);
        }
    }
}
